COS60008 Assignment 2 - 11/05/2024

In order to run the document, simply open the assignment2.ipynb file and restart kernel and run all cells (icon identified as two play buttons connected side-by-side to each other).

This should restart the entire ipynb file from scratch and run all of the subsequent cells!