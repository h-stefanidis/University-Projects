<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="description" content="enhancements" />
        <meta name="keywords" content="enhancements" />
        <meta name="author" content="Harrison Stefanidis" />
        <title>Enhancements</title>

        <!-- Tab Icon -->
        <link rel="icon" type="image/x-icon" href="images/enhance.png">

        <!-- CSS For HTML -->
        <link href="styles/style.css" rel="stylesheet" />
        <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet'>

    </head>
    <body>
        <!-- Title -->
        <?php include 'headerenhancements.inc'; ?>

        <!-- Navigation -->
        <?php include 'menu.inc'; ?>

        <!-- Enhancement 1 -->
        <section id="enhancements1">
        <h2>Enhancement 1 - Favicons</h2>
        <p> The first enhancement is a favicon, which is the addition of an icon at at the top of the tab in your browser. This adds
            an extra aesthetic to the overall look of the page and indicates what the page might have as an insight for further
            information. Unlike the general lecture content web pages, which has no icon presented, these tabs do. In order to apply 
            this method, a link to an image in your folder must be presented in the head of your HTML. This must occur after the title 
            has been introduced so that it shows itself on the browser tab. Examples of these favicons can be found in any of the tabs 
            found in the navigation bar.</p>
        <h3>Sources</h3>
        <a href="https://www.w3schools.com/html/html_favicon.asp">https://www.w3schools.com/html/html_favicon.asp</a>
        <a href="https://mercury.swin.edu.au/cos60004/s105260443/assign1/index.html">https://mercury.swin.edu.au/cos60004/s105260443/assign1/index.html</a>
        </section>

        <!-- Enhancement 2 -->
        <section id="enhancements2">
        <h2>Enhancement 2 - CSS Animations</h2>
        <p> The second enhancement covers a simple animation for my "about" page, where animation one looks at the picture of myself
            sliding in from the right side of the page, the second is a right slide in of further information about myself, and the final
            animation presents itself from the bottom of the page and slides up. This extends from the basic format of this
            assignment as animations aren't covered in the general content, and adds interactive behaviour into the webpage. To apply
            this, it is necessary to create three separate keyframes for each id/section and then call upon them with the "animation"
            code to see it applied when going on to that webpage. You must ensure that the navigation bar remains above this animation
            in the z-axis so that you can still access the menu after the animation has occurred.
        </p>
        <h3>Sources</h3>
        <a href="https://www.w3schools.com/css/css3_animations.asp">https://www.w3schools.com/css/css3_animations.asp</a>
        <a href="https://mercury.swin.edu.au/cos60004/s105260443/assign1/about.html">https://mercury.swin.edu.au/cos60004/s105260443/assign1/about.html</a>
        </section>

        <!-- Footer -->
        <?php include 'footer.inc'; ?>
    </body>
</html>