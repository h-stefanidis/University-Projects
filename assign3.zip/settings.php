<?php
/* settings.php
   General settings to access online database
   Author: Harrison Stefanidis
*/

	$host = "feenix-mariadb.swin.edu.au";
	$user = "s105260443";
	$pwd = "Gemini17H";
	$sql_db = "s105260443_db";
?>
	
	
	