export default function TutorQuizStatisticPage() {
  return <div>TutorQuizStatisticPage</div>;
}
