export default function QuizStatisticPage() {
  return <div>QuizStatisticPage</div>;
}
